import { initCaroselUl } from "./slideAnimation.js";
const init = () => {
  initCaroselUl();
};
init();